from sqlalchemy.orm import Session
from app.models.reservation import Reservation
from app.schemas.reservation import ReservationCreate, ReservationUpdate

def get_reservation(db: Session, reservation_id: int):
    return db.query(Reservation).filter(Reservation.id == reservation_id).first()

def get_reservations(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Reservation).offset(skip).limit(limit).all()

def create_reservation(db: Session, reservation_in: ReservationCreate, user_id: int):
    db_reservation = Reservation(**reservation_in.dict(), user_id=user_id)
    db.add(db_reservation)
    db.commit()
    db.refresh(db_reservation)
    return db_reservation

def update_reservation(db: Session, db_reservation: Reservation, reservation_in: ReservationUpdate):
    for field, value in reservation_in.dict(exclude_unset=True).items():
        setattr(db_reservation, field, value)
    db.commit()
    db.refresh(db_reservation)
    return db_reservation

def delete_reservation(db: Session, db_reservation: Reservation):
    db.delete(db_reservation)
    db.commit()

from sqlalchemy.orm import Session
from app.models.room import Room
from app.schemas.room import RoomCreate, RoomUpdate

def get_room(db: Session, room_id: int):
    return db.query(Room).filter(Room.id == room_id).first()

def get_rooms(db: Session, skip: int = 0, limit: int = 100):
    return db.query(Room).offset(skip).limit(limit).all()

def create_room(db: Session, room_in: RoomCreate):
    db_room = Room(**room_in.dict())
    db.add(db_room)
    db.commit()
    db.refresh(db_room)
    return db_room

def update_room(db: Session, db_room: Room, room_in: RoomUpdate):
    for field, value in room_in.dict(exclude_unset=True).items():
        setattr(db_room, field, value)
    db.commit()
    db.refresh(db_room)
    return db_room

def delete_room(db: Session, db_room: Room):
    db.delete(db_room)
    db.commit()

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.schemas.room import RoomCreate, RoomRead, RoomUpdate
from app.db.session import get_db
from app.crud.room import (
    get_room,
    get_rooms,
    create_room,
    update_room,
    delete_room
)
from app.core.security import get_current_user, get_current_admin
from app.models.user import User

router = APIRouter()

@router.post("/", response_model=RoomRead, status_code=status.HTTP_201_CREATED)
def create_room_endpoint(room_in: RoomCreate, db: Session = Depends(get_db), current_admin: User = Depends(get_current_admin)):
    return create_room(db, room_in)

@router.get("/", response_model=List[RoomRead])
def list_rooms(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return get_rooms(db, skip, limit)

@router.get("/{room_id}", response_model=RoomRead)
def get_room_endpoint(room_id: int, db: Session = Depends(get_db)):
    room = get_room(db, room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    return room

@router.put("/{room_id}", response_model=RoomRead)
def update_room_endpoint(room_id: int, room_in: RoomUpdate, db: Session = Depends(get_db), current_admin: User = Depends(get_current_admin)):
    db_room = get_room(db, room_id)
    if not db_room:
        raise HTTPException(status_code=404, detail="Room not found")
    return update_room(db, db_room, room_in)

@router.delete("/{room_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_room_endpoint(room_id: int, db: Session = Depends(get_db), current_admin: User = Depends(get_current_admin)):
    db_room = get_room(db, room_id)
    if not db_room:
        raise HTTPException(status_code=404, detail="Room not found")
    delete_room(db, db_room)

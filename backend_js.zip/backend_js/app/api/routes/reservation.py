from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.schemas.reservation import ReservationCreate, ReservationRead, ReservationUpdate
from app.db.session import get_db
from app.crud.reservation import (
    get_reservation,
    get_reservations,
    create_reservation,
    update_reservation,
    delete_reservation
)
from app.models.user import User
from app.core.security import get_current_user

router = APIRouter()

@router.post("/", response_model=ReservationRead, status_code=status.HTTP_201_CREATED)
def create_reservation_endpoint(
    reservation_in: ReservationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return create_reservation(db, reservation_in, current_user.id)

@router.get("/", response_model=List[ReservationRead])
def list_reservations(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return get_reservations(db, skip, limit)

@router.get("/{reservation_id}", response_model=ReservationRead)
def get_reservation_endpoint(reservation_id: int, db: Session = Depends(get_db)):
    reservation = get_reservation(db, reservation_id)
    if not reservation:
        raise HTTPException(status_code=404, detail="Reservation not found")
    return reservation

@router.put("/{reservation_id}", response_model=ReservationRead)
def update_reservation_endpoint(
    reservation_id: int,
    reservation_in: ReservationUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    db_reservation = get_reservation(db, reservation_id)
    if not db_reservation:
        raise HTTPException(status_code=404, detail="Reservation not found")
    if db_reservation.user_id != current_user.id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Not enough permissions")
    return update_reservation(db, db_reservation, reservation_in)

@router.delete("/{reservation_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_reservation_endpoint(
    reservation_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    db_reservation = get_reservation(db, reservation_id)
    if not db_reservation:
        raise HTTPException(status_code=404, detail="Reservation not found")
    if db_reservation.user_id != current_user.id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Not enough permissions")
    delete_reservation(db, db_reservation)

from pydantic import BaseModel
from datetime import datetime
from typing import Optional
from app.models.reservation import ReservationStatus

class ReservationBase(BaseModel):
    room_id: int
    start_time: datetime
    end_time: datetime

class ReservationCreate(ReservationBase):
    pass

class ReservationRead(ReservationBase):
    id: int
    user_id: int
    status: ReservationStatus

    class Config:
        orm_mode = True

class ReservationUpdate(BaseModel):
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    status: Optional[ReservationStatus] = None

from fastapi import FastAPI
from app.api.routes import auth, user, room, reservation
from app.db.session import engine
from app.db.base import Base
import app.models  # noqa

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Room Reservation API")

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(user.router, prefix="/users", tags=["users"])
app.include_router(room.router, prefix="/rooms", tags=["rooms"])
app.include_router(reservation.router, prefix="/reservations", tags=["reservations"])

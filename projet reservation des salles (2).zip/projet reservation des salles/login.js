import React, { useState } from 'react';
import axios from 'axios';

function Login() {
  const [formData, setFormData] = useState({ username: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:8000/login', formData);
      alert('Connexion réussie ! Token : ' + res.data.access_token);
    } catch (err) {
      alert('Erreur de connexion');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Connexion</h2>
      <input type="text" placeholder="Nom d'utilisateur" onChange={(e) => setFormData({ ...formData, username: e.target.value })} />
      <input type="password" placeholder="Mot de passe" onChange={(e) => setFormData({ ...formData, password: e.target.value })} />
      <button type="submit">Se connecter</button>
    </form>
  );
}

export default Login;
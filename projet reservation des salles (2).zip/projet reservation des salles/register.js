import React, { useState } from 'react';
import axios from 'axios';

function Register() {
  const [formData, setFormData] = useState({ username: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8000/register', formData);
      alert('Inscription réussie !');
    } catch (err) {
      alert('Erreur lors de l’inscription');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Inscription</h2>
      <input type="text" placeholder="Nom d'utilisateur" onChange={(e) => setFormData({ ...formData, username: e.target.value })} />
      <input type="password" placeholder="Mot de passe" onChange={(e) => setFormData({ ...formData, password: e.target.value })} />
      <button type="submit">S'inscrire</button>
    </form>
  );
}

export default Register;
